Görkem Kadir Solun 22003214

1. Open the designated directory in your Python interpreter.
2. Install the required libraries/packages using pip:
   - `pip install matplotlib`
   - `pip install numpy`
   - `pip install pandas`
   - `pip install pillow`
3. Execute the code, ensuring that you adjust the file path to match the location of your image dataset. 
   Make sure the dataset is extracted into a directory instead of being left in a zip file; otherwise, the code will not read the data properly.
4. Press 1 for PCA and press 2 for Logistic Regression